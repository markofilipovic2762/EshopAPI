create function limit_to_30_rows() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Brišemo sve redove osim poslednjih 30 prema ID koloni
    DELETE FROM menza.narudzbe
    WHERE id IN (
        SELECT id FROM menza.narudzbe
        ORDER BY id ASC
        OFFSET 30
    );
    RETURN NULL;
END;
$$;

alter function limit_to_30_rows() owner to postgres;

